package com.sda.zdtestpol128.steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyFirstStepdefs {
    @Given("this is given step")
    public void thisIsGivenStep() {
        
    }

    @When("this is when step")
    public void thisIsWhenStep() {
        
    }

    @Then("this is then step")
    public void thisIsThenStep() {
        
        
    }

    @And("This is another then step")
    public void thisIsAnotherThenStep() {
    }
}
